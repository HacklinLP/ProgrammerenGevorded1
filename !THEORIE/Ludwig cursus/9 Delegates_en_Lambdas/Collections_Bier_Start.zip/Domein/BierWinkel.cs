﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Domein
{
	public class BierWinkel
	{

		private readonly List<Bier> _bieren;
		private readonly IBierRepository _bierRepo;

		public BierWinkel(IBierRepository bierRepo)
		{
			_bierRepo = bierRepo;
			_bieren = _bierRepo.GeefBieren();
		}

		public List<Bier> GeefBieren()
		{
			throw new NotImplementedException();
		}

		public int GeefAantalBierenMetMinAlcoholPercentage(double percentage)
		{
			throw new NotImplementedException();
		}

		public List<Bier> GeefAlleBierenMetMinAlcoholPercentage(double percentage)
		{
			throw new NotImplementedException();
		}

		public List<string> GeefNamenBieren()
		{
			throw new NotImplementedException();
		}

		//Bier met hoogst aantal graden
		public Bier GeefBierMetHoogsteAlcoholPercentage()
		{
			throw new NotImplementedException();
		}

		//Bier met laagst aantal graden
		public Bier GeefBierMetLaagsteAlcoholPercentage()
		{
			throw new NotImplementedException();
		}

		/*Zorg ervoor dat het resultaat gesorteerd wordt op alcoholgehalte van hoog naar laag, 
		 en bij gelijk aantal graden op naam (alfabetisch).
		 */
		public List<Bier> GeefGeordendOpAlcoholGehalteEnNaam()
		{
			throw new NotImplementedException();
		}

		//Alle brouwerijen
		public List<string> GeefAlleNamenBrouwerijen()
		{
			throw new NotImplementedException();
		}

		//Alle brouwerijen die het woord "van" bevatten
		public List<string> GeefAlleNamenBrouwerijenMetWoord(string woord)
		{
			throw new NotImplementedException();
		}

		public Dictionary<string, Bier> OpzettenOverzichtBierPerNaam()
		{
			throw new NotImplementedException();
		}
		
		public Dictionary<string, List<Bier>> OpzettenOverzichtBierenPerSoort()
		{
			throw new NotImplementedException();
		}

		public Dictionary<string, int> OpzettenAantalBierenPerSoort()
		{
			throw new NotImplementedException();
		}
	}
}