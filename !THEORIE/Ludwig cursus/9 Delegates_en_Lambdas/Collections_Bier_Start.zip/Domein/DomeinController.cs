﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Domein
{

	public class DomeinController
	{

		private readonly BierWinkel _bierWinkel;

		public DomeinController(IBierRepository bierRepo)
		{
			_bierWinkel = new BierWinkel(bierRepo);
		}

		public int GeefAantalBierenMetMinAlcoholPercentage(double percentage)
		{
			throw new NotImplementedException();
		}

		public List<string> GeefLijstAlleBierenMetMinAlcoholPercentage(double percentage)
		{
			throw new NotImplementedException();
		}

		public string GeefNamenBieren()
		{
			throw new NotImplementedException();
		}

		public string GeefAlleNamenBrouwerijen()
		{
			throw new NotImplementedException();
		}

		public List<string> GeefAlleBieren()
		{
			throw new NotImplementedException();
		}

		public string GeefBierMetHoogsteAlcoholPercentage()
		{
			throw new NotImplementedException();
		}

		public string GeefBierMetLaagsteAlcoholPercentage()
		{
			throw new NotImplementedException();
		}

		public List<string> GeefGeordendOpAlcoholGehalteEnNaam()
		{
			throw new NotImplementedException();
		}

		public string GeefAlleNamenBrouwerijenMetWoord(string woord)
		{
			throw new NotImplementedException();
		}

		public string OpzettenAantalBierenPerSoort()
		{
			throw new NotImplementedException();
		}

		public string OpzettenOverzichtBierenPerSoort()
		{
			throw new NotImplementedException();
		}
	}
}