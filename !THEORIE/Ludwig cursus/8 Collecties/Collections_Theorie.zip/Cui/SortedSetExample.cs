﻿using System;
using System.Collections.Generic;

namespace ui
{
	//tag::codeExample[]
	public class SortedSetExample
	{
		private static readonly string[] _Names = new string[] {"yellow", "green", "black", "tan", "grey", "white", "orange", "red", "green"};

		public SortedSetExample()
		{
			SortedSet<string> tree = new SortedSet<string>(_Names);
			Console.WriteLine("sorted set: ");
			PrintSet(tree);

			// alle elementen die < zijn dan element "orange"
			Console.Write("\nView between \"a\" and \"m\":  ");
			PrintSet(tree.GetViewBetween("a","m"));
			
			// het eerste en het laatste element
			Console.Write("first: {0}\n", tree.Min);
			Console.Write("last : {0}\n", tree.Max);
		}


		private void PrintSet(SortedSet<string> set)
		{
			foreach (string s in set)
			{
				Console.Write("{0} ", s);
			}
			Console.WriteLine();
		}

		public static void Main(string[] args)
		{
			new SortedSetExample();
		}

	}
	//end::codeExample[]
}