﻿using System;
using System.Diagnostics;

namespace ui
{
	public class StackUnwindingExceptions
	{
		public static void Main(string[] args)
		{
			try
			{
				Method1();
			}
			catch (Exception exception) // catch exception thrown in method1
			{
				Debug.Write($"{exception.Message}\n\n");
				Debug.Write($"{exception.ToString()}\n\n");

				Console.WriteLine(exception.ToString());
				Console.Write(exception.StackTrace);

			}
		} // end main

		// call method2; throw exceptions back to main
		public static void Method1()
		{
			Method2();
		}

		// call method3; throw exceptions back to method1
		public static void Method2()
		{
			Method3();
		}

		// throw Exception back to method2
		public static void Method3()
		{
			throw new Exception("Exception thrown in method3");
		}
	}

}