﻿using System;

namespace ui
{
	public class UsingExceptions
	{

	   public static void Main(string[] args)
	   {
		  try
		  {
			 ThrowException();
		  }
		  catch (Exception) // exception thrown by throwException
		  {
			 Console.WriteLine("Exception handled in main");
		  }

		  DoesNotThrowException();
	   }

	   public static void ThrowException()
	   {
		  try // throw an exception and immediately catch it
		  {
			 Console.WriteLine("Method throwException");
			 throw new Exception(); // generate exception
		  }
		  catch (Exception exception) // catch exception thrown in try
		  {
			 Console.WriteLine("Exception handled in method throwException");
                throw; // rethrow for further processing

                // code here would not be reached; would cause compilation errors

            }
		  finally // executes regardless of what occurs in try...catch
		  {
			 Console.WriteLine("Finally executed in throwException");
		  }

		  // code here would not be reached; would cause compilation errors

	   }

	   public static void DoesNotThrowException()
	   {
		  try // try block does not throw an exception
		  {
			 Console.WriteLine("Method doesNotThrowException");
		  }
		  catch (Exception exception) // does not execute
		  {
			 Console.WriteLine(exception);
		  }
		  finally // executes regardless of what occurs in try...catch
		  {
			 Console.WriteLine("Finally executed in doesNotThrowException");
		  }

		  Console.WriteLine("End of method doesNotThrowException");
	   }
	}
}