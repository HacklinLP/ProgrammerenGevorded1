﻿using System;
using System.Diagnostics;

namespace ui
{
	//tag::codeExample[]
	public class DivideByZeroWithExceptionHandling
	{

		public static int BerekenQuotient(int teller, int noemer)
		{
			return teller / noemer;
		}

		public static void Main(string[] args)
		{

			bool blijvenHerhalenFlag = true;
			do
			{
				//tag::codeBlock_1[]
				try
				{
					Console.Write("Geef een integere waarde voor de teller: ");
					int teller = Int32.Parse(Console.ReadLine());
					Console.Write("Geef een integere waarde voor de noemer: ");
					int noemer = Int32.Parse(Console.ReadLine());

					int quotient = BerekenQuotient(teller, noemer);
					
					Console.Write($"\nResultaat: {teller} / {noemer} = {quotient}\n");
					
					blijvenHerhalenFlag = false;
				}
				//end::codeBlock_1[]
				//tag::codeBlock_2[]
				catch (FormatException formatException)
				{
					Debug.Write("\nException: {0}\n", formatException.Message);
					
					Console.Write("De invoer moeten integere getallen zijn. Probeer opnieuw.\n\n");
				}
				catch (ArithmeticException arithmeticException)
				{
					Debug.Write("\nException: {0}\n", arithmeticException.Message);
					Console.Write("Het cijfer 0 kan geen noemer zijn. Probeer opnieuw.\n\n");
				}
				//tag::codeBlock_3[]
				catch (Exception exception) // ALL-catcher
				{
					Console.Write("\nException: %s\n", exception);
				}
				//end::codeBlock_3[]
				//end::codeBlock_2[]
			} while (blijvenHerhalenFlag);
		}
	}
	//end::codeExample[]

}