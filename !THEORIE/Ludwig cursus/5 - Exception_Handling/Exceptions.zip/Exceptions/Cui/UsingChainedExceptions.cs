﻿using System;

namespace ui
{
	public class UsingChainedExceptions
	{
	   public static void Main(string[] args)
	   {
		  try
		  {
			 Method1();
		  }
		  catch (Exception exception) // exceptions thrown from method1
		  {
			 Console.WriteLine(exception.ToString());
			 Console.Write(exception.StackTrace);
		  }
	   }

	   // call method2; throw exceptions back to main
	   public static void Method1()
	   {
		  try
		  {
			 Method2();
		  }
		  catch (Exception exception) // exception thrown from method2
		  {
			 throw new Exception("Exception thrown in method1", exception);
		  }
	   } // end method method1

	   // call method3; throw exceptions back to method1
	   public static void Method2()
	   {
		  try
		  {
			 Method3();
		  }
		  catch (Exception exception) // exception thrown from method3
		  {
			 throw new Exception("Exception thrown in method2", exception);
		  }
	   } // end method method2

	   // throw Exception back to method2
	   public static void Method3()
	   {
		  throw new Exception("Exception thrown in method3");
	   }
	}

}