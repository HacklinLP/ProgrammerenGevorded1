﻿using System;

namespace Cui
{
    //tag::codeExample[]
    public class DivideByZeroNoExceptionHandling
    {

        public static int BerekenQuotient(int teller, int noemer)
        {
            return teller / noemer;
        }

        public static void Main(string[] args)
        {
            Console.Write("Geef een integere waarde voor de teller: ");
            int teller = Int32.Parse(Console.ReadLine());

            Console.Write("Geef een integere waarde voor de noemer: ");
            int noemer = Int32.Parse(Console.ReadLine());

            int quotient = BerekenQuotient(teller, noemer);
            Console.Write($"\nResultaat: {teller} / {noemer} = {quotient}\n");
        }
    }
    //end::codeExample[]
}