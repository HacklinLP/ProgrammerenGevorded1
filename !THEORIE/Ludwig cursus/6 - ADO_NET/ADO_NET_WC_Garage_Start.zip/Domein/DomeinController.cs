﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Domein
{

	public class DomeinController
	{
		private Garage _garage;
		public DomeinController(IAutoRepository autoRepo, IOnderhoudRepository onderhoudRepo)
		{
			_garage = new Garage(autoRepo, onderhoudRepo);
		}

		public List<string> GeefAutos()
		{
			return _garage.GeefAutos()
				.Select(Auto => Auto.ToString())
				.ToList();
		}
	}
}