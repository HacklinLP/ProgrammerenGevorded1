﻿namespace Domain.WizardingWorld
{
    public class CeoWizard : Wizard
    {
        public override double TotalSpecialPower => 1000;
        public override double SpecialPowerUses => 6;
    }
}
