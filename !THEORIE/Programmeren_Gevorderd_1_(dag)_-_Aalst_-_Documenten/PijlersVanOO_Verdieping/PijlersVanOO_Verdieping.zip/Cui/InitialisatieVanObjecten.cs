﻿namespace Cui
{
	using Vierkant = Domein.Figuren.Vierkant;

	//tag::codeExample[]
	public class InitialisatieVanObjecten
	{
		public static void Main(string[] args)
		{
			new Vierkant("Mijn vierkant");
		}
	}
	//end::codeExample[]

}