﻿using System;

namespace Cui
{

	//tag::codeExample[]
	internal class Radio
	{ // Superklasse
		public virtual void SpeelMuziek()
		{
			Console.WriteLine("De radio speelt muziek");
		}
	}

	internal class KlassiekeRadio : Radio
	{ // Subklasse
		public override void SpeelMuziek()
		{
			base.SpeelMuziek(); // <1>
			Console.WriteLine("De klassieke radio speelt: Mozart");
		}
	}

	public class RadioApp
	{
		public static void Main(string[] args)
		{
			KlassiekeRadio radio = new KlassiekeRadio();
			radio.SpeelMuziek();
		}
	}
	//end::codeExample[]

}