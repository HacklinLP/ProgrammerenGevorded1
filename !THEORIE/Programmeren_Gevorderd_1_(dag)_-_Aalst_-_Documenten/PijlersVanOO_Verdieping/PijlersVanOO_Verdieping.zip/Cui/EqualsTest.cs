﻿using System;
using System.Collections.Generic;

namespace Cui
{
    //tag::codeExample[]
    public class Student
    {
		public string Naam { get; set; }

		public Student(string naam)
        {
			Naam = naam;
        }

        public override bool Equals(object obj)
        {
           if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            Student s = (Student)obj;

            if (Naam.Equals(s.Naam))
            {
                return true;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
	
	public class EqualsTest
	{
		public static void Main(string[] args)
        {
            
            Student s1 = new Student("Jan");
            Student s2 = new Student("Jan");

			Console.WriteLine(s1 == s2); // <1>
			Console.WriteLine(s1.Equals(s2)); // <2>
		}
	}
	//end::codeExample[]

}