﻿using System;

namespace Domein.Figuren
{
	//tag::codeExample[]
	public class Veelhoek : Figuur
	{
		public Veelhoek(string naam) : base(naam)
		{
			Console.WriteLine("Constructor Veelhoek");
		}
	}
	//end::codeExample[]

}