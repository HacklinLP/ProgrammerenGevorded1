﻿using System;

namespace Domein.Figuren
{
	//tag::codeExample[]
	public class Rechthoek : Veelhoek
	{
		public Rechthoek(string naam) : base(naam)
		{
			Console.WriteLine("Constructor Rechthoek");
		}
	}
	//end::codeExample[]

}