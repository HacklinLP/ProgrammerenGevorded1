﻿using System;

namespace Domein.Figuren
{
	//tag::codeExample[]
	public class Vierkant : Rechthoek
	{
		public Vierkant(string naam) : base(naam)
		{

			Console.WriteLine("Constructor Vierkant");
		}
	}
	//end::codeExample[]

}