﻿using System;

namespace Domein.Figuren
{
	//tag::codeExample[]
	public class Figuur
	{
		private string _naam;

		public Figuur(string naam)
		{
			Console.WriteLine("Constructor Figuur");

			this._naam = naam;
		}
	}
	//end::codeExample[]

}