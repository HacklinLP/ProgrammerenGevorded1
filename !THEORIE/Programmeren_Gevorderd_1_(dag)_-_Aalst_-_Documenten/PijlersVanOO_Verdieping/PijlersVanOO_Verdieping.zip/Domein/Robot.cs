﻿namespace Domein
{
	//tag::codeExample[]

	public class Robot
	{
		private readonly string _type;
		private readonly int _serieNummer; // Uniek serienummer

		public Robot(string type, int serieNummer) : base()
		{
			this._type = type;
			this._serieNummer = serieNummer;
		}

		public override int GetHashCode()
		{ // <2>
			const int prime = 31;
			int result = 1;
			result = prime * result + _serieNummer;
			return result;
		}

		public override bool Equals(object obj)
		{
			if (this == obj)
			{
				return true;
			}
			if (obj == null)
			{
				return false;
			}
			if (this.GetType() != obj.GetType())
			{
				return false;
			}
			Robot other = (Robot) obj;
			if (_serieNummer != other._serieNummer) // <1>
			{
				return false;
			}
			return true;
		}
	}
	//end::codeExample[]

}