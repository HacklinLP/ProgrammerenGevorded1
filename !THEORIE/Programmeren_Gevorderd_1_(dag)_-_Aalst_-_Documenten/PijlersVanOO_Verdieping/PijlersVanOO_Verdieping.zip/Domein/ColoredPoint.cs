﻿namespace Domein
{
	//tag::codeExample[]
	public class Point
	{
		private int _x, _y;

		public Point(int x, int y)
		{
			this._x = x;
			this._y = y;
		}
	}

	public class ColoredPoint : Point
	{
		private const int WHITE = 0, BLACK = 1;
		private int _color;

		public ColoredPoint(int x, int y) : this(x, y, WHITE) // <1>
		{
		}

		public ColoredPoint(int x, int y, int color) : base(x, y) // <2>
		{
			this._color = color;
		}
	}
	//end::codeExample[]
}