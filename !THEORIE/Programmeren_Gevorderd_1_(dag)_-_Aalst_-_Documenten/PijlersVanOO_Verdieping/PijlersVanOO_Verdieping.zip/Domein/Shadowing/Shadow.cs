﻿using System;

namespace Domein.Shadowing
{
	//tag::codeExample[]
	public class Shadow
	{
		private int i = 5; // <1>

		public static void Main(string[] args)
		{
			Shadow shadow = new Shadow();

			shadow.Foo();
		}

		public void Foo()
		{
			int i = 7; // <2>

			Console.WriteLine("Local i = " + i); // <3>
			Console.WriteLine("Class attribute i = " + this.i); // <4>
		}
	}
	//end::codeExample[]
}