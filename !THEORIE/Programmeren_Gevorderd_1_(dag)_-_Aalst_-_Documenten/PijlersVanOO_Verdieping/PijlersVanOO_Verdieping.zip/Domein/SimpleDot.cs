﻿namespace Domein
{
	//tag::codeExample[]
	public abstract class Dot
	{ // <1>
		public int x = 1, y = 1;

		public virtual void Move(int dx, int dy)
		{
			x += dx;
			y += dy;
			Alert();
		}

		public abstract void Alert(); // <2>
	}

	public abstract class ColoredDot : Dot
	{ // <3>
		public int color;
	}

	public class SimpleDot : Dot
	{ // <4>
		public override void Alert()
		{
		}
	}
	//end::codeExample[]
}