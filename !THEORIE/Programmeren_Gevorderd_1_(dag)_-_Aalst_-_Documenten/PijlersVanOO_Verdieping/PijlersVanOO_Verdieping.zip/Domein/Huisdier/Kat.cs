﻿using System;

namespace Domein.Huisdier
{

	//tag::KatEnkelConstructor[]
	public class Kat : Huisdier
	{
		public Kat(string naam) : base(naam)
		{
		}
		//end::KatEnkelConstructor[]

		//tag::KatMaakGeluid[]
		public override string MaakGeluid()
		{
			return "miauw";
		}
		//end::KatMaakGeluid[]

		//tag::KatLuisterNaarNaam[]
		public override bool LuisterNaarNaam(string naam)
		{
			Random r = new Random();
			if (r.Next(10) == 5)
			{
				return base.LuisterNaarNaam(naam);
			}
			return false;
		}
		//end::KatLuisterNaarNaam[]

		//tag::KatSpin[]
		public virtual string Spin()
		{
			return base.Naam + " spint";
		}
		//end::KatSpin[]
	}

}