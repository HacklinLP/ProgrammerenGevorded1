﻿namespace Domein.Huisdier
{
	//tag::codeExample[]
	public abstract class Huisdier //extends Object
	{
		private string _naam;

		public Huisdier(string naam)
		{
			Naam = naam;
		}
		public virtual string Naam
		{
			get
			{
				return _naam;
			}
			set
			{
				this._naam = value;
			}
		}
		public virtual bool LuisterNaarNaam(string naam)
		{
			return (naam.Equals(this._naam));
		}
		public override string ToString()
		{
			return string.Format("{0} met naam {1}", this.GetType().Name, _naam);
		}

		public abstract string MaakGeluid();
	}
	//end::codeExample[]

}