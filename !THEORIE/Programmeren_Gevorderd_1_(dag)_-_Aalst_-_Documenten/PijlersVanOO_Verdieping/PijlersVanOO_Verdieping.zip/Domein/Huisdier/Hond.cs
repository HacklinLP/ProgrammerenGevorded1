﻿namespace Domein.Huisdier
{

	public class Hond : Huisdier
	{
		public Hond(string naam) : base(naam)
		{
		}

		public override string MaakGeluid()
		{
			string geluid = "waf waf!";
			return geluid;
		}

		public virtual string Kwispel()
		{
			return "kwispel-kwispel-kwispel";
		}

	}

}