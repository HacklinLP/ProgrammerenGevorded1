﻿using System;
using System.Collections.Generic;

namespace Domein.Huisdier
{

	public class DierenWinkel
	{
		internal IList<Kat> deKatten = new List<Kat>();
		internal IList<Hond> deHonden = new List<Hond>();

		public DierenWinkel()
		{
			deKatten.Add(new Kat("Garfield"));
			deKatten.Add(new Kat("Pluche"));

			deHonden.Add(new Hond("Nala"));
			deHonden.Add(new Hond("Kamiel"));
		}

		public virtual void MaakKennis()
		{
			foreach (Hond h in deHonden)
			{
//JAVA TO C# CONVERTER TODO TASK: The following line has a Java format specifier which cannot be directly translated to .NET:
				Console.Write("%s: %s%n", h.Naam, h.MaakGeluid());
			}

			foreach (Kat k in deKatten)
			{
//JAVA TO C# CONVERTER TODO TASK: The following line has a Java format specifier which cannot be directly translated to .NET:
				Console.Write("%s: %s%n", k.Naam, k.MaakGeluid());
			}
		}
	}

}