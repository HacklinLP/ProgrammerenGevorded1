﻿using System;

namespace Examples
{

	//tag::codeExample[]
	public class FunctionApply
	{
		public static void Main(string[] args)
		{
			// Function met een Integer als argument en
			// en Double als return type
			Func<int, double> half = a => a / 2.0; // <1>

			// Voer de Function methode apply uit met argument 10.
			Console.WriteLine(half(10));
		}
	}
	//end::codeExample[]
}