﻿using System;

namespace Examples
{
    //tag::codeExample[]
    public class HelloWorldMethodMapping
	{
		// Declaration of a delegate HelloWorld
		private delegate void HelloWorld(string someone);
		private string Prefix = "Hello ";

		private void SayHello(HelloWorld greeting) // Delegate as parameter of a function
		{
			greeting("Peter"); // Invoke the delegate
		}

		private void InstanceMethod(String s)
		{
			// Notice this instance method still has access to the instance variables
			Console.WriteLine(Prefix + s);
		}

		public static void Main(string[] args)
		{
			HelloWorldMethodMapping myApp = new HelloWorldMethodMapping();

			// Mapping of static method to delegate
			myApp.SayHello(Console.WriteLine); // <1>

			// Mapping of instance method to delegate
			myApp.SayHello(myApp.InstanceMethod); // <2>
		}
	}
	//end::codeExample[]

}