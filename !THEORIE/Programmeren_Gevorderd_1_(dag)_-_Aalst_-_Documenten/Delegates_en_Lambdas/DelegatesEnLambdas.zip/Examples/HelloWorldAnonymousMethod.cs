﻿using System;

namespace Examples
{
	//tag::codeExample[]
	public class HelloWorldAnonymousMethod
	{
		private delegate void HelloWorld(string someone);

		public void SayHello()
		{
			// Anonymous method
			//tag::codeExampleFrenchGreeting[]
			HelloWorld frenchGreeting = delegate(string someone) // <1>
			{ 
			Console.WriteLine("Salut " + someone);
			};
			//end::codeExampleFrenchGreeting[]

			frenchGreeting("Fred");
		}

		public static void Main(string[] args)
		{
			HelloWorldAnonymousMethod myApp = new HelloWorldAnonymousMethod();
			myApp.SayHello();
		}
	}
	//end::codeExample[]

}