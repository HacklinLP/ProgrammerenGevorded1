﻿using System;

namespace Examples
{

	//tag::codeExample[]
	public class SupplierGet
	{
		public static void Main(string[] args)
		{
			// This function returns a random value. 
			Func<double> randomValue = () => MathHelper.NextDouble;

			// Print the random value using get() 
			Console.WriteLine(randomValue());
		}
	}
	//end::codeExample[]
}