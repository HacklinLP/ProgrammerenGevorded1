﻿using System;
using System.Collections.Generic;

namespace Examples
{

	//tag::codeExample[]
	public class ConsumerAccept
	{
		public static void Main(string[] args)
		{
			// Consumer to display a number 
			Action<int> display = a => Console.WriteLine(a); // <1>

			// Invoke Console.WriteLine through delegate 
			display(10);

			IList<int> list = new List<int>();
			list.Add(2);
			list.Add(1);
			list.Add(3);

			// Action to display a number 
			Action<IList<int>> displayList = DisplayList;

			// Display the list 
			displayList(list);

			// Consumer die elk element in een lijst verdubbelt
			Action<IList<int>> multiplyElementsByTwo = a =>
			{
				for (int i = 0; i < a.Count; i++)
				{
					list[i] = 2 * a[i];
				}
			};

			// Multicast delegate: verdubbel elk element in de lijst en 
			// druk elk element af op het scherm
			Action<IList<int>> multiplyAndDisplay = multiplyElementsByTwo + displayList; // <2>

			multiplyAndDisplay(list);
		}
		private static void DisplayList(IList<int> list)
        {
			foreach (int i in list)
            {
                Console.WriteLine(i);
            }
        }
	}
	//end::codeExample[]
}