﻿using System;

namespace Examples
{

	//tag::codeExample[]
	public class HelloWorldLambdaExpression
	{
		private delegate void HelloWorld(string someone);
		private const string Prefix = "Hello ";

		private void SayHello(HelloWorld greeting)
		{
			greeting("Peter");
		}

		public static void Main(string[] args)
		{
			HelloWorldLambdaExpression myApp = new HelloWorldLambdaExpression();

			//tag::codeExampleDutchGreeting[]
			HelloWorld dutchGreeting = (string someone) => // <1>
			{ 
				string name = someone;
				Console.WriteLine(Prefix + name);
			};
			//end::codeExampleDutchGreeting[]

			myApp.SayHello(dutchGreeting);

            myApp.SayHello(s => Console.WriteLine(Prefix + s)); // <2>
		}
	}
	//end::codeExample[]

}