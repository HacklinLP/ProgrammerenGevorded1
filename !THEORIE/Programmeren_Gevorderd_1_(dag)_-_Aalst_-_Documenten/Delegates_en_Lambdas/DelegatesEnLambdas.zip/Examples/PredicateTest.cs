﻿using System;
using System.Collections.Generic;

namespace Examples
{

	//tag::codeExample[]
	public class PredicateTest
	{
		public static void Pred(int number, Predicate<int> predicate)
		{
			// Voer de Predicate uit op het eerste argument number
			if (predicate(number))
			{
				Console.Write($"De voorwaarde op nummer {number} is true.\n");
			}
			else
			{
				Console.Write($"De voorwaarde op nummer {number} is false.\n");
			}
		}

		public static void Main(string[] args)
		{
			// Predicate met voorwaarde "< 18"
			Predicate<int> lessThan18 = i => (i < 18); // <1>

			// Test de voorwaarde  
			Console.WriteLine(lessThan18(10));

			// Predicate met voorwaarde "> 12"
			Predicate<int> greaterThan12 = (i) => i > 12;

			// Test de voorwaarde  
			Console.WriteLine(greaterThan12(10));

			// Samengestelde predicate 
			Predicate<int> lessThan18AndGreaterThan12 = i => lessThan18(i) && greaterThan12(i);

			bool result = lessThan18AndGreaterThan12(16); // <2>
			Console.WriteLine(result);

			// Negatie van een Predicate
			Predicate<int> negateLessThan18AndGreaterThan12 = (x) => !lessThan18AndGreaterThan12(x);
			bool result2 = negateLessThan18AndGreaterThan12(16); // <3>
			Console.WriteLine(result2);

			// Using a lambda expression
			Pred(10, (i) => i > 7);
		}
	}
	//end::codeExample[]
}