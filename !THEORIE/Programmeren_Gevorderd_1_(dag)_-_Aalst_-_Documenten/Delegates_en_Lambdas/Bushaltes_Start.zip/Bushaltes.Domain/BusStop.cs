﻿namespace BusStops.Domain
{
    public class BusStop
    {
        public int StopNumber { get; set; }
        public string StopName { get; set; }
        public string StopAccessibilities { get; set; }
        public string Municipality { get; set; }
    }
}
