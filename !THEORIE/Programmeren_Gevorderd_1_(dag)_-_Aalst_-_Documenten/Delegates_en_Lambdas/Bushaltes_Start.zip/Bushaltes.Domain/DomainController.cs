﻿namespace BusStops.Domain
{
    public class DomainController
    {
        private IBusStopsRepository _repository;
        public DomainController(IBusStopsRepository repository)
        {
            _repository = repository;
        }
    }
}
