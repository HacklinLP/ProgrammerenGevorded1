﻿namespace BusStops.Domain
{
    public interface IBusStopsRepository
    {
    }
}
