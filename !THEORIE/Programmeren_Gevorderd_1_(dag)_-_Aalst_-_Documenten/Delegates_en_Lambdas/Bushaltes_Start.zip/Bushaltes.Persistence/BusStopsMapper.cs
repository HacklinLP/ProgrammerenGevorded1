﻿using BusStops.Domain;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

namespace BusStops.Persistence
{
    public class BusStopsMapper : IBusStopsRepository
    {
        private List<BusStop> _bushaltes;
        public BusStopsMapper()
        {
            // If the .json file is not found! (e.g. you get an exception...)
            // Open Project > Properties > Configuration Properties > Debugging.
            // Change The Working Directory entry to $(SolutionDir)
            // Place your json file next to your project .sln file

            _bushaltes = JsonConvert.DeserializeObject<List<BusStop>>(File.ReadAllText(@"bushaltes-gent-short.json"));
        }
    }
}
