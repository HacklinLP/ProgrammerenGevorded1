﻿using BusStops.Domain;

namespace BusStops.Presentation
{
    public class BusStopsApplication
    {
        private DomainController _domainController;
        public BusStopsApplication(DomainController domainController)
        {
            _domainController = domainController;
        }
    }
}