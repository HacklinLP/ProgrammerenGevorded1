﻿List<string> _names = new()
{
	"jean",
	"marc",
	"patrick",
	"luc",
	"michel",
	"philippe",
	"jan",
	"david",
	"mohamed",
	"thomas",
	"maria",
	"marie",
	"martine",
	"nathalie",
	"monique",
	"anne",
	"rita",
	"nicole",
	"christine",
	"isabelle",
};

// We want to only get names that are shorter than 7 characters and do not contain the letter M.
// We also want to capitalize the first letter.

const string ExcludedLetter = "m";
const int NameMaxLength = 7;

Console.WriteLine(string.Join(" ", PrintNamesWithForeachLoop(_names)));
Console.WriteLine(string.Join(" ", PrintNamesWithLinq(_names)));
Console.WriteLine(string.Join(" ", PrintNamesWithLinqChaining(_names)));

// Method 1: for loops
static IEnumerable<string> PrintNamesWithForeachLoop(List<string> names)
{
	List<string> shortNames = new();
	foreach (string name in names)
	{
		if (name.Length < NameMaxLength && !name.Contains(ExcludedLetter))
		{
			shortNames.Add(CapitalizeFirstLetter(name));
		}
	}

	return shortNames;
}

// Method 2: linq queries
static IEnumerable<string> PrintNamesWithLinq(List<string> names)
{
	// Do not convert to List immediately to delay execution until we need the values.
	IEnumerable<string> shortNames = names.Where(n => n.Length < NameMaxLength);
	IEnumerable<string> shortNamesWithoutM = shortNames.Where(n => !n.Contains(ExcludedLetter));
	IEnumerable<string> capitalizedShortNamesWithoutM = shortNamesWithoutM.Select(n => CapitalizeFirstLetter(n));

	return capitalizedShortNamesWithoutM;
}

// Method 3: linq queries with chaining
static IEnumerable<string> PrintNamesWithLinqChaining(List<string> names)
{
	return names
		.Where(n => n.Length < NameMaxLength)
		.Where(n => !n.Contains(ExcludedLetter))
		.Select(n => CapitalizeFirstLetter(n));
}

static string CapitalizeFirstLetter(string text)
{
	return text[0].ToString().ToUpper() + text.Substring(1, text.Length - 1);
}