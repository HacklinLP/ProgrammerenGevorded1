﻿Queue<int> wachtrij = new();
wachtrij.Enqueue(1);
wachtrij.Enqueue(2);
wachtrij.Enqueue(3);

Console.WriteLine(wachtrij.Dequeue());
Console.WriteLine(wachtrij.Peek());
Console.WriteLine(wachtrij.Dequeue());