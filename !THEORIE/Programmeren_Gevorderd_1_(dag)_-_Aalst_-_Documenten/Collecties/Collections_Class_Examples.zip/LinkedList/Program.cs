﻿LinkedList<int> numbers = new();

numbers.AddLast(1);
numbers.AddFirst(2);

LinkedListNode<int> node = numbers.First;
numbers.AddBefore(node, 3);

// Which order will the values be printed in?
Console.WriteLine(string.Join(" ", numbers));