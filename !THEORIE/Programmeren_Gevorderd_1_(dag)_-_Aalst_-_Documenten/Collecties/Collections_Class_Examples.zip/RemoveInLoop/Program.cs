﻿List<int> integers = new List<int>
{
1,
2,
3,
4,
5,
6,
7,
8,
9,
};

foreach (int integer in integers)
{
	if (integer % 2 == 0)
	{
		integers.Remove(integer);
	}
}

integers.ForEach(x => Console.WriteLine(x));