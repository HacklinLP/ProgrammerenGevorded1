﻿using System.Collections.ObjectModel;

namespace ReadOnlyCollection
{
	internal class SecureZoo
	{
		public ReadOnlyCollection<string> AnimalsReadOnlyCollection { get; init; }
		private List<string> _animalsList;

		public SecureZoo(List<string> animals)
		{
			_animalsList = animals;
			AnimalsReadOnlyCollection = new ReadOnlyCollection<string>(_animalsList);
		}

		public void AddAnimal(string animal)
		{
			_animalsList.Add(animal);
		}
	}
}