﻿namespace ReadOnlyCollection
{
	internal class UnsecureZoo
	{
		private List<string> _animalsList;

		public UnsecureZoo(List<string> animals)
		{
			_animalsList = animals;
		}
		public List<string> AnimalsList
		{
			get => _animalsList;
			init => _animalsList = value;
		}

		public void AddAnimal(string animal)
		{
			_animalsList.Add(animal);
		}
	}
}
