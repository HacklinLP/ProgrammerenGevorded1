﻿using ReadOnlyCollection;

List<string> animals = new List<string> { "pengiun", "tiger", "sloth" };
UnsecureZoo unsecureZoo = new(animals);
SecureZoo secureZoo = new(animals);

unsecureZoo.AnimalsList.Add("chicken");
// This line does not compile as a ReadOnlyCollection does not have an Add function.
secureZoo.AnimalsReadOnlyCollection.Add("chicken");

PrintZooAnimals(unsecureZoo, secureZoo);

unsecureZoo.AddAnimal("cow");
secureZoo.AddAnimal("cow");

PrintZooAnimals(unsecureZoo, secureZoo);


static void PrintZooAnimals(UnsecureZoo unsecureZoo, SecureZoo secureZoo)
{
	Console.WriteLine("Unsecure zoo animals: " + string.Join(" ", unsecureZoo.AnimalsList));
	Console.WriteLine("Secure zoo animals: " + string.Join(" ", secureZoo.AnimalsReadOnlyCollection));
}