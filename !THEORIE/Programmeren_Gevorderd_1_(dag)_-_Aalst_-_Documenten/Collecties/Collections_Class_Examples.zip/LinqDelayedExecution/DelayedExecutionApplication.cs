﻿namespace LinqDelayedExecution
{
	internal class DelayedExecutionApplication
	{
		private List<string> _cities = new()
		{
			"new york",
			"tokyo",
			"brussel"
		};
		private IEnumerable<string> _delayedFilteredCities;
		private List<string> _instantFilteredCities;

		public DelayedExecutionApplication()
		{
			_delayedFilteredCities = _cities.Where(c => !c.StartsWith("b"));

			// ToList() call converts the linq query object to a regular list object.
			_instantFilteredCities = _cities.Where(c => !c.StartsWith("b")).ToList();

			AddCity("gent");
			// Brugge is not shown in outputs because it is filtered by the delayed where query.
			AddCity("brugge");
			AddCity("hasselt");
		}

		private void AddCity(string city)
		{
			_cities.Add(city);
			Console.WriteLine("Added city: " + city);

			// Instant execution list never changes when adding to the _cities list.
			Console.WriteLine("Instant execution: " + string.Join(", ", _instantFilteredCities));

			// Delayed execution is only executed when the delayed list's values are used.
			Console.WriteLine("Delayed execution: " + string.Join(", ", _delayedFilteredCities));

			Console.WriteLine();
		}
	}
}
