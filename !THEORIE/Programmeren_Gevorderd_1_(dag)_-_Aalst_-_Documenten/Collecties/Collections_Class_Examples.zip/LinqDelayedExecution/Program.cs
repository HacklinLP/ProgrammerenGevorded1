﻿using LinqDelayedExecution;

DelayedExecutionApplication delayedExecution = new();