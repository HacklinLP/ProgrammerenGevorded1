﻿using HashSet;

HashSet<Animal> animals = new HashSet<Animal>();

animals.Add(new Animal("ape"));
animals.Add(new Animal("elephant"));
animals.Add(new Animal("tiger"));
animals.Add(new Animal("elephant"));

Console.WriteLine($"Hashset currently contains {animals.Count} animals.");