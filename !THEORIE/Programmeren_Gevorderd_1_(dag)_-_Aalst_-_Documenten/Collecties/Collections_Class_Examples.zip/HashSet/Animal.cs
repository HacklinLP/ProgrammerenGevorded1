﻿namespace HashSet
{
	public class Animal
	{
		public Animal(string name)
		{
			Name = name;
		}

		public string Name { get; init; }

		public override bool Equals(object? obj)
		{
			return obj is Animal animal && Name == animal.Name;
		}

		public override int GetHashCode()
		{
			return HashCode.Combine(Name);
		}
	}
}
