﻿Stack<int> stapel = new();
stapel.Push(1);
stapel.Push(2);
stapel.Push(3);

Console.WriteLine(stapel.Pop());
Console.WriteLine(stapel.Peek());
Console.WriteLine(stapel.Pop());