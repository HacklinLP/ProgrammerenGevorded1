﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logent.Interfaces
{
    public interface IHelpt
    {
        public void Helpt();
    }
}
