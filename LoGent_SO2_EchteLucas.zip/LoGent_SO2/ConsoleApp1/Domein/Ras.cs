﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logent.Domein
{
    public enum Ras
    {
        Sphynx,
        Britse_Korthaar,
        Maine_Coon,
        Ragemuffin
    }
}
